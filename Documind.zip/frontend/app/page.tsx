import { ParseDebugger } from "@/components/ParseDebugger";

export default function Page() {
  return <ParseDebugger />;
}
