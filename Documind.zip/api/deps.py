from __future__ import annotations

import base64
import json
import os
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Annotated
from uuid import UUID

from fastapi import Depends, Header, HTTPException, status
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

DEFAULT_DATABASE_URL = "postgresql+asyncpg://documind:documind_dev@localhost:5432/documind"

DATABASE_URL = os.getenv("DATABASE_URL", DEFAULT_DATABASE_URL)

engine = create_async_engine(
    DATABASE_URL,
    pool_pre_ping=True,
)

AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


@dataclass(frozen=True, slots=True)
class WorkspaceContext:
    workspace_id: UUID
    actor_id: str


def _decode_jwt_payload_without_verification(token: str) -> dict[str, object]:
    parts = token.split(".")
    if len(parts) != 3:
        raise ValueError("Bearer token must be a JWT with three segments.")

    payload = parts[1]
    padding = "=" * (-len(payload) % 4)
    decoded = base64.urlsafe_b64decode(f"{payload}{padding}")
    data = json.loads(decoded)
    if not isinstance(data, dict):
        raise ValueError("JWT payload must be an object.")
    return data


def _extract_bearer_token(authorization: str | None) -> str | None:
    if authorization is None:
        return None
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authorization must be a Bearer token.",
        )
    return token


async def get_workspace_id(
    authorization: Annotated[str | None, Header(alias="Authorization")] = None,
    x_workspace_id: Annotated[str | None, Header(alias="X-Workspace-Id")] = None,
) -> UUID:
    token = _extract_bearer_token(authorization)
    workspace_candidate: object | None = None

    if token is not None:
        try:
            payload = _decode_jwt_payload_without_verification(token)
        except (ValueError, json.JSONDecodeError) as exc:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Bearer token does not contain a readable JWT payload.",
            ) from exc
        workspace_candidate = (
            payload.get("workspace_id")
            or payload.get("org_id")
            or payload.get("tenant_id")
        )

    if workspace_candidate is None:
        workspace_candidate = x_workspace_id

    if workspace_candidate is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Workspace identity is required via Bearer JWT or X-Workspace-Id.",
        )

    try:
        return UUID(str(workspace_candidate))
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Workspace identity must be a valid UUID.",
        ) from exc


async def get_actor_id(
    authorization: Annotated[str | None, Header(alias="Authorization")] = None,
    x_actor_id: Annotated[str | None, Header(alias="X-Actor-Id")] = None,
) -> str:
    token = _extract_bearer_token(authorization)
    if token is not None:
        try:
            payload = _decode_jwt_payload_without_verification(token)
        except (ValueError, json.JSONDecodeError):
            return x_actor_id or "api"
        actor = payload.get("sub") or payload.get("actor_id") or payload.get("email")
        if actor is not None:
            return str(actor)
    return x_actor_id or "api"


async def apply_workspace_rls(session: AsyncSession, workspace_id: UUID) -> None:
    await session.execute(text(f"SET LOCAL app.workspace_id = '{workspace_id}'"))


async def get_db(
    workspace_id: Annotated[UUID, Depends(get_workspace_id)],
) -> AsyncIterator[AsyncSession]:
    async with AsyncSessionLocal() as session:
        try:
            await apply_workspace_rls(session, workspace_id)
            yield session
            if session.in_transaction():
                await session.commit()
        except Exception:
            if session.in_transaction():
                await session.rollback()
            raise


@asynccontextmanager
async def open_workspace_session(workspace_id: UUID) -> AsyncIterator[AsyncSession]:
    async with AsyncSessionLocal() as session:
        try:
            await apply_workspace_rls(session, workspace_id)
            yield session
            if session.in_transaction():
                await session.commit()
        except Exception:
            if session.in_transaction():
                await session.rollback()
            raise


async def get_workspace_context(
    workspace_id: Annotated[UUID, Depends(get_workspace_id)],
    actor_id: Annotated[str, Depends(get_actor_id)],
) -> WorkspaceContext:
    return WorkspaceContext(workspace_id=workspace_id, actor_id=actor_id)
