from __future__ import annotations

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import WorkspaceContext, get_db, get_workspace_context
from api.models.parse import ParseBlockRow, ParseRun
from api.models.split_classify import ClassificationRun
from api.schemas.classify import ClassifyRunRequest, ClassifyRunResponse
from workers.classify_worker import classify_pages

router = APIRouter(prefix="/v1/classify", tags=["classify"])


@router.post("/runs", response_model=ClassifyRunResponse)
async def create_classify_run(
    ctx: Annotated[WorkspaceContext, Depends(get_workspace_context)],
    db: Annotated[AsyncSession, Depends(get_db)],
    body: ClassifyRunRequest,
) -> ClassifyRunResponse:
    try:
        await _require_parse_run(ctx, db, body.parse_run_id)
        blocks = await _load_parse_blocks(ctx, db, body.parse_run_id)
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    result = classify_pages(blocks, body.taxonomy)
    db.add(
        ClassificationRun(
            id=result.run_id,
            workspace_id=ctx.workspace_id,
            parse_run_id=body.parse_run_id,
            status="succeeded",
            taxonomy=body.taxonomy,
            page_labels={str(page): label for page, label in result.page_labels.items()},
            scores=result.scores,
        )
    )
    await db.commit()
    return ClassifyRunResponse(run_id=result.run_id, page_labels=result.page_labels)


async def _require_parse_run(
    ctx: WorkspaceContext,
    db: AsyncSession,
    parse_run_id: UUID,
) -> ParseRun:
    result = await db.execute(
        select(ParseRun)
        .where(ParseRun.id == parse_run_id)
        .where(ParseRun.workspace_id == ctx.workspace_id)
    )
    parse_run = result.scalar_one_or_none()
    if parse_run is None:
        raise KeyError(f"parse_run_id not found in workspace: {parse_run_id}")
    return parse_run


async def _load_parse_blocks(
    ctx: WorkspaceContext,
    db: AsyncSession,
    parse_run_id: UUID,
) -> list[dict[str, object]]:
    result = await db.execute(
        select(ParseBlockRow)
        .where(ParseBlockRow.parse_run_id == parse_run_id)
        .where(ParseBlockRow.workspace_id == ctx.workspace_id)
        .order_by(ParseBlockRow.page, ParseBlockRow.reading_order_rank)
    )
    rows = list(result.scalars())
    if not rows:
        raise KeyError(f"parse_run_id has no parse blocks: {parse_run_id}")
    return [row.ast for row in rows]
