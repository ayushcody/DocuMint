from __future__ import annotations

from uuid import UUID

from pydantic import Field

from api.schemas.common import StrictBaseModel


class ClassifyRunRequest(StrictBaseModel):
    parse_run_id: UUID
    taxonomy: list[str] = Field(min_length=1)


class ClassifyRunResponse(StrictBaseModel):
    run_id: UUID
    page_labels: dict[int, str]
