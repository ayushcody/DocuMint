from __future__ import annotations

from uuid import UUID

from pydantic import Field

from api.schemas.common import BBox, StrictBaseModel


class CollectionCreateRequest(StrictBaseModel):
    name: str
    enable_binary_quantization: bool = True


class CollectionCreateResponse(StrictBaseModel):
    collection_id: UUID
    name: str


class CollectionSyncRequest(StrictBaseModel):
    parse_run_ids: list[UUID] = Field(min_length=1)


class CollectionSyncResponse(StrictBaseModel):
    collection_id: UUID
    queued_documents: int
    pages_indexed: int = 0
    status: str = "ready"


class RetrievalQueryRequest(StrictBaseModel):
    collection_id: UUID
    query: str
    limit: int = Field(default=5, ge=1, le=50)


class RetrievalHit(StrictBaseModel):
    document_id: UUID
    page: int = Field(ge=0)
    score: float = Field(ge=0.0)
    bbox: BBox
    image_patch_path: str


class RetrievalQueryResponse(StrictBaseModel):
    hits: list[RetrievalHit]
