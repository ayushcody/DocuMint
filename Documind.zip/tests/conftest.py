from __future__ import annotations

import pytest


def pytest_addoption(parser: pytest.Parser) -> None:
    parser.addoption(
        "--integration",
        action="store_true",
        default=False,
        help="run integration tests that require external services or heavy models",
    )
    parser.addoption(
        "--regression",
        action="store_true",
        default=False,
        help="run golden-set regression tests",
    )


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:
    skip_integration = pytest.mark.skip(reason="need --integration option to run")
    skip_regression = pytest.mark.skip(reason="need --regression option to run")
    run_integration = bool(config.getoption("--integration"))
    run_regression = bool(config.getoption("--regression"))

    for item in items:
        if "integration" in item.keywords and not run_integration:
            item.add_marker(skip_integration)
        if "regression" in item.keywords and not run_regression:
            item.add_marker(skip_regression)
