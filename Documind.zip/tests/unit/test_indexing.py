import numpy as np

from workers.indexing import (
    binary_quantize,
    hybrid_retrieval_score,
    maxsim_late_interaction,
    reciprocal_rank_fusion,
)


def test_maxsim_late_interaction_uses_best_patch_per_query_token() -> None:
    query = np.array([[1.0, 0.0], [0.0, 1.0]])
    document = np.array([[1.0, 0.0], [0.0, 1.0], [-1.0, 0.0]])

    score = maxsim_late_interaction(query, document)

    assert score == 2.0


def test_hybrid_retrieval_score_matches_guideline_weights() -> None:
    score = hybrid_retrieval_score(1.0, 0.5, 1.0, 0.0, 0.5)

    assert score == 0.75


def test_reciprocal_rank_fusion_combines_rankings() -> None:
    fused = reciprocal_rank_fusion([["a", "b"], ["b", "c"]], k=60)

    assert fused["b"] > fused["a"]
    assert fused["b"] > fused["c"]


def test_binary_quantization_outputs_signed_bits() -> None:
    quantized = binary_quantize(np.array([[-0.1, 0.0, 0.3]]))

    assert quantized.tolist() == [[-1, 1, 1]]
