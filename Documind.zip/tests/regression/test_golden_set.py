from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from workers.extraction import CalibratedConfidence

GOLDEN_SET_DIR = Path("golden_set")
REQUIRED_CASES = [
    "sec_10k",
    "invoice",
    "bank_statement",
    "scanned_contract",
    "academic_paper",
    "phone_photo",
    "handwritten",
]

pytestmark = pytest.mark.regression


def _load_expected(case_name: str) -> dict[str, Any]:
    with (GOLDEN_SET_DIR / f"{case_name}.expected.json").open() as handle:
        return json.load(handle)


def _pdf_path(case_name: str) -> Path | None:
    root_pdf = GOLDEN_SET_DIR / f"{case_name}.pdf"
    if root_pdf.exists():
        return root_pdf
    nested_pdf = GOLDEN_SET_DIR / case_name / "input.pdf"
    if nested_pdf.exists():
        return nested_pdf
    return None


CASES = [(name, _load_expected(name)) for name in REQUIRED_CASES]


def test_expected_manifests_exist_for_all_golden_documents() -> None:
    missing = [
        str(GOLDEN_SET_DIR / f"{case_name}.expected.json")
        for case_name in REQUIRED_CASES
        if not (GOLDEN_SET_DIR / f"{case_name}.expected.json").exists()
    ]
    assert missing == []


@pytest.mark.parametrize("case_name,expected", CASES)
def test_expected_manifest_schema(case_name: str, expected: dict[str, Any]) -> None:
    assert expected["doc_type"]
    assert expected["page_count"] >= 1
    assert expected["block_types"]
    assert "expected_confidence_calibrated_min" in expected
    assert isinstance(expected.get("extraction", {}), dict), case_name


@pytest.mark.asyncio
@pytest.mark.parametrize("case_name,expected", CASES)
async def test_parse_block_coverage(case_name: str, expected: dict[str, Any]) -> None:
    pdf_path = _pdf_path(case_name)
    if pdf_path is None:
        pytest.skip(f"No golden PDF present for {case_name}")
    pytest.fail(
        "Golden parse execution is not wired to the full local service harness yet. "
        f"Expected block types: {expected['block_types']}"
    )


@pytest.mark.asyncio
@pytest.mark.parametrize("case_name,expected", CASES)
async def test_teds_score(case_name: str, expected: dict[str, Any]) -> None:
    pdf_path = _pdf_path(case_name)
    if pdf_path is None:
        pytest.skip(f"No golden PDF present for {case_name}")
    if not expected.get("tables"):
        pytest.skip(f"No table ground truth for {case_name}")
    pytest.fail("TEDS benchmark runner is not implemented yet")


@pytest.mark.asyncio
@pytest.mark.parametrize("case_name,expected", CASES)
async def test_extraction_field_accuracy(case_name: str, expected: dict[str, Any]) -> None:
    pdf_path = _pdf_path(case_name)
    if pdf_path is None:
        pytest.skip(f"No golden PDF present for {case_name}")
    if not expected.get("extraction"):
        pytest.skip(f"No extraction ground truth for {case_name}")
    pytest.fail("Golden extraction runner is not implemented yet")


def test_confidence_ece_below_threshold_contract() -> None:
    calibrator = CalibratedConfidence()
    raw = [0.05, 0.20, 0.45, 0.70, 0.92]
    truth = [0.0, 0.0, 0.0, 1.0, 1.0]
    calibrator.fit(raw, truth)
    calibrated = [calibrator.calibrate(score) for score in raw]
    ece = calibrator.ece(calibrated, truth)
    assert ece < 0.05
