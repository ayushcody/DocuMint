# DocuMind AI

DocuMind AI is an open-core, agentic Document AI platform scaffolded from the project guideline. The first build focuses on the contracts that matter most: workspace isolation, parse-block transparency, verifier scores, calibrated confidence, bounding-box citations, and visual debugging.

## Structure

- `api/`: FastAPI app, routers, Pydantic schemas, service layer, and SQLAlchemy models.
- `workers/`: the seven-agent pipeline modules.
- `frontend/`: Next.js 14 parse debugger with canvas bbox overlays and Zustand sync.
- `infra/`: local Docker Compose services, Helm skeleton, and monitoring config.
- `golden_set/`: regression-set directories and expected artifact placeholders.
- `tests/`: unit tests for mathematical formulas and core contracts.

## Local Backend

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
uvicorn api.main:app --reload
```

All API requests require a workspace header:

```bash
X-Workspace-Id: 00000000-0000-0000-0000-000000000001
```

## Local Frontend

```bash
cd frontend
npm install
npm run dev
```

## Local Services

```bash
docker compose -f infra/docker-compose.yml up
```

This starts PostgreSQL, Redis, MinIO, Qdrant, Prometheus, and Grafana for local development.

## Deployment Profiles

`DOCUMINT_PROFILE` controls which model dependencies are required at startup:

```bash
DOCUMINT_PROFILE=parse_only     # Agents 1-4 only
DOCUMINT_PROFILE=parse_extract  # Agents 1-6, no RAG
DOCUMINT_PROFILE=rag_only       # Agent 7 indexing/retrieval only
DOCUMINT_PROFILE=full           # All 7 agents, default
```

RAG routes return HTTP 503 unless the profile is `full` or `rag_only`.

## Current Scope

This is a first-pass build scaffold. Heavy model integrations are intentionally represented as typed service stubs so the architecture can be tested and extended without pretending that YOLOv9, MinerU, olmOCR, ColPali, Triton, or vLLM are already deployed locally.
