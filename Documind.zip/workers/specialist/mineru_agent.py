from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class MinerUResult:
    block_id: str
    localized_markdown: str
    structured_json: dict[str, object]
    raw_confidence: float


async def parse_complex_region(
    block_id: str,
    anchor_text: str,
    crop_object_path: str,
) -> MinerUResult:
    text = anchor_text.strip()
    return MinerUResult(
        block_id=block_id,
        localized_markdown=text,
        structured_json={"crop_object_path": crop_object_path, "anchor_text": text},
        raw_confidence=0.70 if text else 0.25,
    )
