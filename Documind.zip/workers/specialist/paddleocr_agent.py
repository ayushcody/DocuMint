from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class SpecialistResult:
    block_id: str
    markdown: str
    html: str
    raw_confidence: float
    engine: str


async def parse_simple_text_region(block_id: str, anchor_text: str) -> SpecialistResult:
    text = anchor_text.strip()
    return SpecialistResult(
        block_id=block_id,
        markdown=text,
        html=f"<p>{_escape_html(text)}</p>",
        raw_confidence=0.96 if text else 0.20,
        engine="native_pdf_anchor",
    )


def _escape_html(text: str) -> str:
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )
