from __future__ import annotations

import asyncio
import io
import logging
import os
import tempfile
from dataclasses import dataclass

from PIL import Image

from workers.layout import NativeSpan

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class TableResult:
    html: str
    teds_estimate: float


@dataclass(frozen=True, slots=True)
class MinerUResult:
    text: str
    html: str
    tables: list[TableResult]
    confidence: float
    engine: str
    warning: str | None


async def parse_complex_region(
    crop_bytes: bytes,
    native_spans: list[NativeSpan],
    block_type: str,
) -> MinerUResult:
    logger.warning(
        "MinerU STUB: using marker-pdf CPU fallback when available. "
        "Replace with MinerU2.5-Pro NaViT on GPU before production."
    )
    marker_result = await _try_marker_pdf(crop_bytes)
    if marker_result is not None:
        text, html = marker_result
        tables = (
            [TableResult(html=html, teds_estimate=0.45)]
            if block_type == "table" and html
            else []
        )
        return MinerUResult(
            text=text,
            html=html,
            tables=tables,
            confidence=0.62 if text else 0.25,
            engine="marker_pdf_cpu_fallback",
            warning="MinerU stub - marker-pdf CPU fallback, not MinerU2.5-Pro",
        )

    text = " ".join(span["text"] for span in native_spans if span["text"].strip()).strip()
    if block_type == "table":
        table_html = _native_text_to_table_html(text)
        return MinerUResult(
            text=text,
            html=table_html,
            tables=[TableResult(html=table_html, teds_estimate=0.55 if text else 0.0)],
            confidence=0.72 if text else 0.25,
            engine="native_pdf_table_fallback",
            warning="MinerU stub - swap to MinerU2.5-Pro NaViT on GPU",
        )

    html = f"<div>{_escape_html(text)}</div>"
    return MinerUResult(
        text=text,
        html=html,
        tables=[],
        confidence=0.70 if text else 0.25,
        engine="native_pdf_complex_fallback",
        warning="MinerU stub - swap to MinerU2.5-Pro NaViT on GPU",
    )


async def _try_marker_pdf(crop_bytes: bytes) -> tuple[str, str] | None:
    try:
        from marker.converters.pdf import PdfConverter  # type: ignore[import-not-found]
        from marker.models import create_model_dict  # type: ignore[import-not-found]
        from marker.output import text_from_rendered  # type: ignore[import-not-found]
    except ImportError:
        logger.error("marker-pdf not installed; returning native span text for complex region")
        return None

    tmp_path = ""
    try:
        image = Image.open(io.BytesIO(crop_bytes)).convert("RGB")
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
            tmp_path = tmp.name
        await asyncio.to_thread(image.save, tmp_path, "PDF", resolution=300.0)
        models = await asyncio.to_thread(create_model_dict)
        converter = PdfConverter(artifact_dict=models)
        rendered = await asyncio.to_thread(converter, tmp_path)
        rendered_text = await asyncio.to_thread(text_from_rendered, rendered)
        markdown = _rendered_text_to_markdown(rendered_text, rendered)
        html = str(getattr(rendered, "html", "") or "")
        if not html and markdown:
            html = _markdown_tables_to_html(markdown)
        return markdown, html
    except Exception as exc:
        logger.error("marker-pdf fallback failed: %s", exc)
        return None
    finally:
        if tmp_path:
            try:
                os.unlink(tmp_path)
            except FileNotFoundError:
                pass


def _native_text_to_table_html(text: str) -> str:
    tokens = [token for token in text.split() if token]
    if not tokens:
        return "<table></table>"
    cells = "".join(f"<td>{_escape_html(token)}</td>" for token in tokens)
    return f"<table><tbody><tr>{cells}</tr></tbody></table>"


def _rendered_text_to_markdown(rendered_text: object, rendered: object) -> str:
    if isinstance(rendered_text, tuple) and rendered_text:
        return str(rendered_text[0] or "")
    if isinstance(rendered_text, str):
        return rendered_text
    return str(getattr(rendered, "markdown", "") or "")


def _markdown_tables_to_html(markdown: str) -> str:
    html_parts: list[str] = []
    table_rows: list[list[str]] = []
    in_table = False

    for line in markdown.splitlines():
        if "|" in line and line.strip().startswith("|"):
            in_table = True
            cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
            table_rows.append(cells)
            continue
        if in_table:
            html_parts.append(_rows_to_html_table(table_rows))
            table_rows = []
            in_table = False
        if line.strip():
            html_parts.append(f"<p>{_escape_html(line.strip())}</p>")

    if in_table:
        html_parts.append(_rows_to_html_table(table_rows))
    return "\n".join(part for part in html_parts if part)


def _rows_to_html_table(rows: list[list[str]]) -> str:
    if not rows:
        return ""
    html_rows: list[str] = []
    for index, row in enumerate(rows):
        if index == 1 and all(set(cell) <= set("-: ") for cell in row):
            continue
        tag = "th" if index == 0 else "td"
        html_rows.append(
            "<tr>" + "".join(f"<{tag}>{_escape_html(cell)}</{tag}>" for cell in row) + "</tr>"
        )
    return "<table>" + "".join(html_rows) + "</table>"


def _escape_html(text: str) -> str:
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )
