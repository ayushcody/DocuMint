from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class OlmOCRResult:
    block_id: str
    markdown: str
    raw_confidence: float


async def parse_degraded_or_handwritten_region(
    block_id: str,
    crop_object_path: str,
    anchor_text: str,
) -> OlmOCRResult:
    del crop_object_path
    text = anchor_text.strip()
    return OlmOCRResult(
        block_id=block_id,
        markdown=text,
        raw_confidence=0.58 if text else 0.18,
    )
