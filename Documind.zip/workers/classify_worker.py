from __future__ import annotations

import hashlib
from dataclasses import dataclass
from uuid import UUID, uuid4

import numpy as np
from numpy.typing import NDArray


@dataclass(frozen=True, slots=True)
class ClassificationResult:
    run_id: UUID
    page_labels: dict[int, str]
    scores: dict[str, float]


def classify_pages(
    parse_blocks: list[dict[str, object]],
    taxonomy: list[str],
    threshold: float = 0.4,
) -> ClassificationResult:
    page_text = _page_text(parse_blocks)
    taxonomy_vectors = {label: _text_embedding(label) for label in taxonomy}
    labels: dict[int, str] = {}
    scores: dict[str, float] = {}
    for page, text in page_text.items():
        page_vector = _text_embedding(text)
        ranked = sorted(
            (
                (_cosine(page_vector, category_vector), category)
                for category, category_vector in taxonomy_vectors.items()
            ),
            reverse=True,
        )
        best_score, best_label = ranked[0]
        labels[page] = best_label if best_score >= threshold else "uncertain"
        scores[str(page)] = float(best_score)
    return ClassificationResult(run_id=uuid4(), page_labels=labels, scores=scores)


def _page_text(parse_blocks: list[dict[str, object]]) -> dict[int, str]:
    pages: dict[int, list[str]] = {}
    for block in parse_blocks:
        page = int(block.get("page", 0))
        pages.setdefault(page, []).append(str(block.get("text", "")))
    return {page: "\n".join(parts) for page, parts in pages.items()}


def _text_embedding(text: str) -> NDArray[np.float64]:
    tokens = [token for token in text.lower().split() if token]
    if not tokens:
        tokens = ["empty"]
    vectors = [_hash_token(token) for token in tokens[:64]]
    return np.mean(np.vstack(vectors), axis=0)


def _hash_token(token: str) -> NDArray[np.float64]:
    digest = hashlib.sha256(token.encode("utf-8")).digest()
    raw = np.frombuffer((digest * 4)[:128], dtype=np.uint8).astype(np.float64)
    return (raw / 127.5) - 1.0


def _cosine(a: NDArray[np.float64], b: NDArray[np.float64]) -> float:
    denominator = float(np.linalg.norm(a) * np.linalg.norm(b))
    if denominator == 0:
        return 0.0
    return float(np.dot(a, b) / denominator)
