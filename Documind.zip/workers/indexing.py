from __future__ import annotations

import asyncio
import hashlib
import io
import os
from dataclasses import dataclass
from uuid import UUID

import httpx
import numpy as np
from numpy.typing import NDArray
from PIL import Image

QDRANT_URL = os.getenv("QDRANT_URL", "http://localhost:6333")
VECTOR_SIZE = 128

_colpali_model: object | None = None
_colpali_processor: object | None = None


@dataclass(frozen=True, slots=True)
class IndexedChunk:
    vector_ref: str
    document_id: UUID
    parse_run_id: UUID
    page: int
    text: str
    bbox: dict[str, object]
    embeddings: list[list[float]]
    metadata: dict[str, object]


def build_chunk_embeddings(
    collection_id: UUID,
    document_id: UUID,
    parse_run_id: UUID,
    parse_blocks: list[dict[str, object]],
) -> list[IndexedChunk]:
    chunks: list[IndexedChunk] = []
    for block in parse_blocks:
        block_id = str(block["block_id"])
        text = str(block.get("text", ""))
        bbox = block.get("bbox", {})
        if not isinstance(bbox, dict):
            bbox = {"x": 0.0, "y": 0.0, "w": 1.0, "h": 1.0, "coord_space": "page_norm"}
        embeddings = _multi_vector_for_text_and_bbox(text, bbox)
        vector_ref = f"{collection_id}:{parse_run_id}:{block_id}"
        chunks.append(
            IndexedChunk(
                vector_ref=vector_ref,
                document_id=document_id,
                parse_run_id=parse_run_id,
                page=int(block.get("page", 0)),
                text=text,
                bbox=bbox,
                embeddings=embeddings.tolist(),
                metadata={
                    "collection_id": str(collection_id),
                    "block_id": block_id,
                    "image_patch_path": str(block.get("source", {}).get("crop_path", "")),
                },
            )
        )
    return chunks


async def upsert_qdrant_chunks(collection_id: UUID, chunks: list[IndexedChunk]) -> bool:
    if not chunks:
        return True
    collection_name = _collection_name(collection_id)
    async with httpx.AsyncClient(timeout=5.0) as client:
        try:
            await _ensure_qdrant_collection(client, collection_name)
            points = [
                {
                    "id": _stable_point_id(chunk.vector_ref),
                    "vector": {"patches": chunk.embeddings},
                    "payload": {
                        **chunk.metadata,
                        "document_id": str(chunk.document_id),
                        "parse_run_id": str(chunk.parse_run_id),
                        "page": chunk.page,
                        "text": chunk.text,
                        "bbox": chunk.bbox,
                    },
                }
                for chunk in chunks
            ]
            response = await client.put(
                f"{QDRANT_URL}/collections/{collection_name}/points",
                json={"points": points},
            )
            response.raise_for_status()
            return True
        except (httpx.HTTPError, httpx.TimeoutException):
            return False


async def embed_page_colpali(page_image_bytes: bytes) -> list[list[float]]:
    def encode() -> list[list[float]]:
        import torch  # type: ignore[import-not-found]

        model, processor = _get_colpali()
        image = Image.open(io.BytesIO(page_image_bytes)).convert("RGB")
        inputs = processor.process_images([image])
        inputs = {key: value.to(model.device) for key, value in inputs.items()}
        with torch.no_grad():
            embeddings = model(**inputs)
        return embeddings[0].cpu().float().tolist()

    return await asyncio.to_thread(encode)


async def create_colpali_collection(
    client_or_collection_name: object,
    collection_name: str | None = None,
) -> None:
    if collection_name is None:
        client = None
        resolved_collection_name = str(client_or_collection_name)
    else:
        client = client_or_collection_name
        resolved_collection_name = collection_name

    def create() -> None:
        from qdrant_client.models import (  # type: ignore[import-not-found]
            BinaryQuantization,
            BinaryQuantizationConfig,
            Distance,
            MultiVectorComparator,
            MultiVectorConfig,
            VectorParams,
        )

        qdrant_client = client
        if qdrant_client is None:
            from qdrant_client import QdrantClient  # type: ignore[import-not-found]

            qdrant_client = QdrantClient(url=QDRANT_URL)

        qdrant_client.recreate_collection(
            collection_name=resolved_collection_name,
            vectors_config=VectorParams(
                size=VECTOR_SIZE,
                distance=Distance.COSINE,
                multivector_config=MultiVectorConfig(
                    comparator=MultiVectorComparator.MAX_SIM,
                ),
            ),
            quantization_config=BinaryQuantization(
                binary=BinaryQuantizationConfig(always_ram=True),
            ),
        )

    await asyncio.to_thread(create)


async def index_page_colpali(
    collection_name: str,
    workspace_id: UUID,
    document_id: UUID,
    page_num: int,
    page_image_bytes: bytes,
    parse_blocks: list[dict[str, object]],
) -> str:
    patch_vectors = await embed_page_colpali(page_image_bytes)
    point_id = _stable_page_point_id(document_id, page_num)

    def upsert() -> None:
        from qdrant_client import QdrantClient  # type: ignore[import-not-found]
        from qdrant_client.models import PointStruct  # type: ignore[import-not-found]

        client = QdrantClient(url=QDRANT_URL)
        client.upsert(
            collection_name=collection_name,
            points=[
                PointStruct(
                    id=point_id,
                    vector=patch_vectors,
                    payload={
                        "workspace_id": str(workspace_id),
                        "document_id": str(document_id),
                        "page_num": page_num,
                        "block_ids": [
                            str(block["block_id"])
                            for block in parse_blocks
                            if int(block.get("page", -1)) == page_num
                        ],
                    },
                )
            ],
        )

    await asyncio.to_thread(upsert)
    return point_id


async def index_page(
    client: object,
    collection_name: str,
    workspace_id: str | UUID,
    document_id: str | UUID,
    page_num: int,
    page_image_bytes: bytes,
    parse_blocks: list[dict[str, object]],
) -> str:
    workspace_uuid = workspace_id if isinstance(workspace_id, UUID) else UUID(str(workspace_id))
    document_uuid = document_id if isinstance(document_id, UUID) else UUID(str(document_id))
    patch_vectors = await embed_page_colpali(page_image_bytes)
    point_id = _stable_page_point_id(document_uuid, page_num)

    def upsert() -> None:
        from qdrant_client.models import PointStruct  # type: ignore[import-not-found]

        client.upsert(
            collection_name=collection_name,
            points=[
                PointStruct(
                    id=point_id,
                    vector=patch_vectors,
                    payload={
                        "workspace_id": str(workspace_uuid),
                        "document_id": str(document_uuid),
                        "page_num": page_num,
                        "block_ids": [
                            str(block["block_id"])
                            for block in parse_blocks
                            if int(block.get("page", -1)) == page_num
                        ],
                    },
                )
            ],
        )

    await asyncio.to_thread(upsert)
    return point_id


async def query_colpali_collection(
    collection_name: str,
    query_text: str,
    workspace_id: UUID,
    limit: int,
) -> list[dict[str, object]]:
    query_vectors = await embed_query_colpali(query_text)

    def search() -> list[dict[str, object]]:
        from qdrant_client import QdrantClient  # type: ignore[import-not-found]  # noqa: I001
        from qdrant_client.models import FieldCondition, Filter, MatchValue  # type: ignore[import-not-found]

        client = QdrantClient(url=QDRANT_URL)
        results = client.search(
            collection_name=collection_name,
            query_vector=query_vectors,
            query_filter=Filter(
                must=[
                    FieldCondition(
                        key="workspace_id",
                        match=MatchValue(value=str(workspace_id)),
                    )
                ]
            ),
            limit=limit,
            with_payload=True,
        )
        return [
            {
                "document_id": result.payload["document_id"],
                "page": result.payload["page_num"],
                "score": float(result.score),
                "block_ids": result.payload.get("block_ids", []),
            }
            for result in results
        ]

    return await asyncio.to_thread(search)


async def embed_query_colpali(query_text: str) -> list[list[float]]:
    def encode() -> list[list[float]]:
        import torch  # type: ignore[import-not-found]

        model, processor = _get_colpali()
        inputs = processor.process_queries([query_text])
        inputs = {key: value.to(model.device) for key, value in inputs.items()}
        with torch.no_grad():
            embeddings = model(**inputs)
        return embeddings[0].cpu().float().tolist()

    return await asyncio.to_thread(encode)


def _get_colpali() -> tuple[object, object]:
    global _colpali_model, _colpali_processor
    if _colpali_model is None or _colpali_processor is None:
        import torch  # type: ignore[import-not-found]  # noqa: I001
        from colpali_engine.models import ColPali, ColPaliProcessor  # type: ignore[import-not-found]

        device = "cuda" if torch.cuda.is_available() else "cpu"
        _colpali_model = ColPali.from_pretrained(
            "vidore/colpali-v1.2",
            torch_dtype=torch.float32,
            device_map=device,
        )
        _colpali_processor = ColPaliProcessor.from_pretrained("vidore/colpali-v1.2")
    return _colpali_model, _colpali_processor


def query_vectors(query: str) -> NDArray[np.float64]:
    tokens = [token for token in query.lower().split() if token]
    if not tokens:
        tokens = [query or "empty"]
    return np.vstack([_hash_embedding(token) for token in tokens]).astype(np.float64)


def score_chunk(query: str, embeddings: list[list[float]]) -> float:
    if not embeddings:
        return 0.0
    return maxsim_late_interaction(query_vectors(query), np.asarray(embeddings, dtype=np.float64))


def maxsim_late_interaction(
    query_vectors: NDArray[np.float64],
    document_vectors: NDArray[np.float64],
) -> float:
    """
    MaxSim(Q,D) = sum_i max_j cosine(q_i, d_j).
    """
    q = _l2_normalize(query_vectors)
    d = _l2_normalize(document_vectors)
    similarities = q @ d.T
    return float(np.max(similarities, axis=1).sum())


def hybrid_retrieval_score(
    s_dense: float,
    s_sparse: float,
    s_visual: float,
    s_meta: float,
    s_rerank: float,
    alpha: float = 0.30,
    beta: float = 0.20,
    gamma: float = 0.30,
    delta: float = 0.10,
    epsilon: float = 0.10,
) -> float:
    return (
        alpha * s_dense
        + beta * s_sparse
        + gamma * s_visual
        + delta * s_meta
        + epsilon * s_rerank
    )


def reciprocal_rank_fusion(rankings: list[list[str]], k: int = 60) -> dict[str, float]:
    fused: dict[str, float] = {}
    for ranking in rankings:
        for rank, doc_id in enumerate(ranking, start=1):
            fused[doc_id] = fused.get(doc_id, 0.0) + 1.0 / (k + rank)
    return fused


def binary_quantize(embeddings: NDArray[np.float64]) -> NDArray[np.int8]:
    return np.where(embeddings >= 0, 1, -1).astype(np.int8)


async def _ensure_qdrant_collection(client: httpx.AsyncClient, collection_name: str) -> None:
    response = await client.put(
        f"{QDRANT_URL}/collections/{collection_name}",
        json={
            "vectors": {
                "patches": {
                    "size": VECTOR_SIZE,
                    "distance": "Cosine",
                    "multivector_config": {"comparator": "max_sim"},
                }
            },
            "quantization_config": {"binary": {"always_ram": True}},
        },
    )
    if response.status_code not in {200, 201}:
        response.raise_for_status()


def _multi_vector_for_text_and_bbox(
    text: str,
    bbox: dict[str, object],
) -> NDArray[np.float64]:
    tokens = [token for token in text.lower().split() if token][:16]
    if not tokens:
        tokens = ["empty"]
    token_vectors = [_hash_embedding(token) for token in tokens]
    bbox_vector = _bbox_embedding(bbox)
    return np.vstack([*token_vectors, bbox_vector])


def _hash_embedding(value: str) -> NDArray[np.float64]:
    digest = hashlib.sha512(value.encode("utf-8")).digest()
    raw = np.frombuffer((digest * 2)[:VECTOR_SIZE], dtype=np.uint8).astype(np.float64)
    return (raw / 127.5) - 1.0


def _bbox_embedding(bbox: dict[str, object]) -> NDArray[np.float64]:
    x = float(bbox.get("x", 0.0))
    y = float(bbox.get("y", 0.0))
    w = float(bbox.get("w", 1.0))
    h = float(bbox.get("h", 1.0))
    base = np.array([x, y, w, h] * (VECTOR_SIZE // 4), dtype=np.float64)
    return (base * 2.0) - 1.0


def _stable_point_id(value: str) -> str:
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()
    return str(UUID(hex=digest[:32]))


def qdrant_collection_name(collection_id: UUID) -> str:
    return f"documind_{str(collection_id).replace('-', '_')}"


def _stable_page_point_id(document_id: UUID, page_num: int) -> str:
    digest = hashlib.sha256(f"{document_id}:{page_num}".encode()).hexdigest()
    return str(UUID(hex=digest[:32]))


def _collection_name(collection_id: UUID) -> str:
    return qdrant_collection_name(collection_id)


def _l2_normalize(vectors: NDArray[np.float64]) -> NDArray[np.float64]:
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    norms = np.where(norms == 0, 1.0, norms)
    return vectors / norms
