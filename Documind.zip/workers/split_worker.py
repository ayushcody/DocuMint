from __future__ import annotations

from dataclasses import dataclass
from uuid import UUID, uuid4


@dataclass(frozen=True, slots=True)
class SplitSegmentResult:
    segment_id: UUID
    start_page: int
    end_page: int
    label: str
    confidence: float

    def as_dict(self) -> dict[str, object]:
        return {
            "segment_id": str(self.segment_id),
            "start_page": self.start_page,
            "end_page": self.end_page,
            "label": self.label,
            "confidence": self.confidence,
        }


def split_document(parse_blocks: list[dict[str, object]]) -> list[SplitSegmentResult]:
    pages = sorted({int(block.get("page", 0)) for block in parse_blocks})
    if not pages:
        return []

    boundaries = [pages[0]]
    for page in pages[1:]:
        previous = page - 1
        if _is_boundary(previous, page, parse_blocks):
            boundaries.append(page)

    segments: list[SplitSegmentResult] = []
    for index, start_page in enumerate(boundaries):
        end_page = (boundaries[index + 1] - 1) if index + 1 < len(boundaries) else pages[-1]
        label = _segment_label(start_page, parse_blocks)
        segments.append(
            SplitSegmentResult(
                segment_id=uuid4(),
                start_page=start_page,
                end_page=end_page,
                label=label,
                confidence=0.82 if label != "document" else 0.68,
            )
        )
    return segments


def _is_boundary(previous_page: int, page: int, blocks: list[dict[str, object]]) -> bool:
    page_blocks = [block for block in blocks if int(block.get("page", 0)) == page]
    previous_blocks = [block for block in blocks if int(block.get("page", 0)) == previous_page]
    if _has_boundary_heading(page_blocks):
        return True
    return _class_distribution(page_blocks) != _class_distribution(previous_blocks)


def _has_boundary_heading(blocks: list[dict[str, object]]) -> bool:
    markers = ("section", "exhibit", "appendix", "schedule")
    for block in blocks:
        text = str(block.get("text", "")).strip().lower()
        bbox = block.get("bbox", {})
        y = float(bbox.get("y", 1.0)) if isinstance(bbox, dict) else 1.0
        if y < 0.25 and text.startswith(markers):
            return True
        if block.get("type") == "header" and y < 0.25:
            return True
    return False


def _class_distribution(blocks: list[dict[str, object]]) -> tuple[str, ...]:
    return tuple(sorted({str(block.get("type", "paragraph")) for block in blocks}))


def _segment_label(start_page: int, blocks: list[dict[str, object]]) -> str:
    page_blocks = [block for block in blocks if int(block.get("page", 0)) == start_page]
    for block in page_blocks:
        text = str(block.get("text", "")).strip()
        if block.get("type") == "header" and text:
            return text[:80]
    for marker in ("Section", "Exhibit", "Appendix", "Schedule"):
        for block in page_blocks:
            text = str(block.get("text", "")).strip()
            if text.startswith(marker):
                return text[:80]
    return "document"
